create index IX_A05AAB19 on CustomizedModel_CustomizedModel (groupId, status);
create index IX_E3D06F3D on CustomizedModel_CustomizedModel (status);
create index IX_8C9718B on CustomizedModel_CustomizedModel (uuid_[$COLUMN_LENGTH:75$], companyId);
create unique index IX_4886DECD on CustomizedModel_CustomizedModel (uuid_[$COLUMN_LENGTH:75$], groupId);