/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.liferay.discussion.test.service.impl;

import com.liferay.discussion.test.exception.InvalidCustomizedModelException;
import com.liferay.discussion.test.model.CustomizedModel;
import com.liferay.discussion.test.service.base.CustomizedModelLocalServiceBaseImpl;
import com.liferay.portal.kernel.comment.CommentManagerUtil;
import com.liferay.portal.kernel.dao.orm.DynamicQuery;
import com.liferay.portal.kernel.dao.orm.RestrictionsFactoryUtil;
import com.liferay.portal.kernel.exception.PortalException;
import com.liferay.portal.kernel.model.ResourceConstants;
import com.liferay.portal.kernel.model.User;
import com.liferay.portal.kernel.util.ContentTypes;
import com.liferay.portal.kernel.workflow.WorkflowConstants;

import java.util.List;
import java.util.Date;

import aQute.bnd.annotation.ProviderType;

/**
 * The implementation of the customized model local service.
 *
 * <p>
 * All custom service methods should be put in this class. Whenever methods are added, rerun ServiceBuilder to copy their definitions into the {@link com.liferay.discussion.test.service.CustomizedModelLocalService} interface.
 *
 * <p>
 * This is a local service. Methods of this service will not have security checks based on the propagated JAAS credentials because this service can only be accessed from within the same VM.
 * </p>
 *
 * @author Brian Wing Shun Chan
 * @see CustomizedModelLocalServiceBaseImpl
 * @see com.liferay.discussion.test.service.CustomizedModelLocalServiceUtil
 */
@ProviderType
public class CustomizedModelLocalServiceImpl
	extends CustomizedModelLocalServiceBaseImpl {
	/*
	 * NOTE FOR DEVELOPERS:
	 *
	 * Never reference this class directly. Always use {@link com.liferay.discussion.test.service.CustomizedModelLocalServiceUtil} to access the customized model local service.
	 */
	
	@Override
	public CustomizedModel addCustomizedModel(long companyId, long groupId, long userId, String title, String body) throws PortalException {
		
		CustomizedModel cm = assembleCustomziedModel(companyId, groupId, userId, title, body);
		
		cm.setStatus(WorkflowConstants.STATUS_APPROVED);

		cm.setStatusByUserId(userId);
		cm.setStatusByUserName(cm.getUserName());
		cm.setStatusDate(cm.getCreateDate());
		
		customizedModelPersistence.update(cm);
		

		resourceLocalService.addResources(companyId, groupId, userId,  CustomizedModel.class.getName(),
				cm.getPrimaryKey(), false, true, false);

		assetEntryLocalService.updateEntry(userId, groupId, cm.getCreateDate(), cm.getCreateDate(), CustomizedModel.class.getName(), 
				cm.getPrimaryKey(), cm.getUuid(), 0, null, null, true, true, null, null, null, null, ContentTypes.TEXT_HTML, 
				title, body, body, null, null, 0, 0, 0.0);
		
		return cm;
	}
	
	@Override
	public CustomizedModel deleteCustomizedModel(long cmId) throws PortalException {
		CustomizedModel cm = customizedModelLocalService.getCustomizedModel(cmId);
		customizedModelPersistence.remove(cm);
		resourceLocalService.deleteResource(cm.getCompanyId(), CustomizedModel.class.getName(), ResourceConstants.SCOPE_INDIVIDUAL, cm.getPrimaryKey());
		assetEntryLocalService.deleteEntry(CustomizedModel.class.getName(), cm.getPrimaryKey());
		CommentManagerUtil.deleteDiscussion(CustomizedModel.class.getName(), cm.getPrimaryKey());
		return cm;
	}
	
	@Override
	public void deleteAll(long groupId) throws PortalException {
		DynamicQuery dq = customizedModelLocalService.dynamicQuery()
				.add(RestrictionsFactoryUtil.eq("groupId", groupId));
		for (Object o : customizedModelLocalService.dynamicQuery(dq)) {
			CustomizedModel cm = (CustomizedModel)o;
			customizedModelLocalService.deleteCustomizedModel(cm);
		}
	}
	
	private CustomizedModel assembleCustomziedModel(Long companyId, long groupId, long userId, String title, String body) throws PortalException {
		if (title == null || title.length() == 0)
			throw new InvalidCustomizedModelException("title is empty");
		CustomizedModel cm = customizedModelPersistence.create(counterLocalService.increment(CustomizedModel.class.getName()));
		User user = userLocalService.getUser(userId);
		cm.setCompanyId(companyId);
		cm.setGroupId(groupId);
		cm.setCreateDate(new Date());
		cm.setUserId(userId);
		cm.setUserName(user.getFullName());
		cm.setTitle(title);
		cm.setBody(body);
		return cm;
	}

}