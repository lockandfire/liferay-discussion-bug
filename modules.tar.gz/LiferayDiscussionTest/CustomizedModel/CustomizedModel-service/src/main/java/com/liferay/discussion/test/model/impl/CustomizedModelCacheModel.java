/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.liferay.discussion.test.model.impl;

import aQute.bnd.annotation.ProviderType;

import com.liferay.discussion.test.model.CustomizedModel;

import com.liferay.portal.kernel.model.CacheModel;
import com.liferay.portal.kernel.util.HashUtil;
import com.liferay.portal.kernel.util.StringBundler;
import com.liferay.portal.kernel.util.StringPool;

import java.io.Externalizable;
import java.io.IOException;
import java.io.ObjectInput;
import java.io.ObjectOutput;

import java.util.Date;

/**
 * The cache model class for representing CustomizedModel in entity cache.
 *
 * @author Brian Wing Shun Chan
 * @see CustomizedModel
 * @generated
 */
@ProviderType
public class CustomizedModelCacheModel implements CacheModel<CustomizedModel>,
	Externalizable {
	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}

		if (!(obj instanceof CustomizedModelCacheModel)) {
			return false;
		}

		CustomizedModelCacheModel customizedModelCacheModel = (CustomizedModelCacheModel)obj;

		if (modelId == customizedModelCacheModel.modelId) {
			return true;
		}

		return false;
	}

	@Override
	public int hashCode() {
		return HashUtil.hash(0, modelId);
	}

	@Override
	public String toString() {
		StringBundler sb = new StringBundler(27);

		sb.append("{uuid=");
		sb.append(uuid);
		sb.append(", modelId=");
		sb.append(modelId);
		sb.append(", groupId=");
		sb.append(groupId);
		sb.append(", companyId=");
		sb.append(companyId);
		sb.append(", userId=");
		sb.append(userId);
		sb.append(", userName=");
		sb.append(userName);
		sb.append(", createDate=");
		sb.append(createDate);
		sb.append(", title=");
		sb.append(title);
		sb.append(", body=");
		sb.append(body);
		sb.append(", status=");
		sb.append(status);
		sb.append(", statusByUserId=");
		sb.append(statusByUserId);
		sb.append(", statusByUserName=");
		sb.append(statusByUserName);
		sb.append(", statusDate=");
		sb.append(statusDate);
		sb.append("}");

		return sb.toString();
	}

	@Override
	public CustomizedModel toEntityModel() {
		CustomizedModelImpl customizedModelImpl = new CustomizedModelImpl();

		if (uuid == null) {
			customizedModelImpl.setUuid(StringPool.BLANK);
		}
		else {
			customizedModelImpl.setUuid(uuid);
		}

		customizedModelImpl.setModelId(modelId);
		customizedModelImpl.setGroupId(groupId);
		customizedModelImpl.setCompanyId(companyId);
		customizedModelImpl.setUserId(userId);

		if (userName == null) {
			customizedModelImpl.setUserName(StringPool.BLANK);
		}
		else {
			customizedModelImpl.setUserName(userName);
		}

		if (createDate == Long.MIN_VALUE) {
			customizedModelImpl.setCreateDate(null);
		}
		else {
			customizedModelImpl.setCreateDate(new Date(createDate));
		}

		if (title == null) {
			customizedModelImpl.setTitle(StringPool.BLANK);
		}
		else {
			customizedModelImpl.setTitle(title);
		}

		if (body == null) {
			customizedModelImpl.setBody(StringPool.BLANK);
		}
		else {
			customizedModelImpl.setBody(body);
		}

		customizedModelImpl.setStatus(status);
		customizedModelImpl.setStatusByUserId(statusByUserId);

		if (statusByUserName == null) {
			customizedModelImpl.setStatusByUserName(StringPool.BLANK);
		}
		else {
			customizedModelImpl.setStatusByUserName(statusByUserName);
		}

		if (statusDate == Long.MIN_VALUE) {
			customizedModelImpl.setStatusDate(null);
		}
		else {
			customizedModelImpl.setStatusDate(new Date(statusDate));
		}

		customizedModelImpl.resetOriginalValues();

		return customizedModelImpl;
	}

	@Override
	public void readExternal(ObjectInput objectInput) throws IOException {
		uuid = objectInput.readUTF();

		modelId = objectInput.readLong();

		groupId = objectInput.readLong();

		companyId = objectInput.readLong();

		userId = objectInput.readLong();
		userName = objectInput.readUTF();
		createDate = objectInput.readLong();
		title = objectInput.readUTF();
		body = objectInput.readUTF();

		status = objectInput.readInt();

		statusByUserId = objectInput.readLong();
		statusByUserName = objectInput.readUTF();
		statusDate = objectInput.readLong();
	}

	@Override
	public void writeExternal(ObjectOutput objectOutput)
		throws IOException {
		if (uuid == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(uuid);
		}

		objectOutput.writeLong(modelId);

		objectOutput.writeLong(groupId);

		objectOutput.writeLong(companyId);

		objectOutput.writeLong(userId);

		if (userName == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(userName);
		}

		objectOutput.writeLong(createDate);

		if (title == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(title);
		}

		if (body == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(body);
		}

		objectOutput.writeInt(status);

		objectOutput.writeLong(statusByUserId);

		if (statusByUserName == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(statusByUserName);
		}

		objectOutput.writeLong(statusDate);
	}

	public String uuid;
	public long modelId;
	public long groupId;
	public long companyId;
	public long userId;
	public String userName;
	public long createDate;
	public String title;
	public String body;
	public int status;
	public long statusByUserId;
	public String statusByUserName;
	public long statusDate;
}