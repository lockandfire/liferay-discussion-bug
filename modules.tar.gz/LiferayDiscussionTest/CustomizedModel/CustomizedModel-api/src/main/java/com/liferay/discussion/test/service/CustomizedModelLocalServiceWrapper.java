/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.liferay.discussion.test.service;

import aQute.bnd.annotation.ProviderType;

import com.liferay.portal.kernel.service.ServiceWrapper;

/**
 * Provides a wrapper for {@link CustomizedModelLocalService}.
 *
 * @author Brian Wing Shun Chan
 * @see CustomizedModelLocalService
 * @generated
 */
@ProviderType
public class CustomizedModelLocalServiceWrapper
	implements CustomizedModelLocalService,
		ServiceWrapper<CustomizedModelLocalService> {
	public CustomizedModelLocalServiceWrapper(
		CustomizedModelLocalService customizedModelLocalService) {
		_customizedModelLocalService = customizedModelLocalService;
	}

	/**
	* Adds the customized model to the database. Also notifies the appropriate model listeners.
	*
	* @param customizedModel the customized model
	* @return the customized model that was added
	*/
	@Override
	public com.liferay.discussion.test.model.CustomizedModel addCustomizedModel(
		com.liferay.discussion.test.model.CustomizedModel customizedModel) {
		return _customizedModelLocalService.addCustomizedModel(customizedModel);
	}

	@Override
	public com.liferay.discussion.test.model.CustomizedModel addCustomizedModel(
		long companyId, long groupId, long userId, java.lang.String title,
		java.lang.String body)
		throws com.liferay.portal.kernel.exception.PortalException {
		return _customizedModelLocalService.addCustomizedModel(companyId,
			groupId, userId, title, body);
	}

	/**
	* Creates a new customized model with the primary key. Does not add the customized model to the database.
	*
	* @param modelId the primary key for the new customized model
	* @return the new customized model
	*/
	@Override
	public com.liferay.discussion.test.model.CustomizedModel createCustomizedModel(
		long modelId) {
		return _customizedModelLocalService.createCustomizedModel(modelId);
	}

	/**
	* Deletes the customized model from the database. Also notifies the appropriate model listeners.
	*
	* @param customizedModel the customized model
	* @return the customized model that was removed
	*/
	@Override
	public com.liferay.discussion.test.model.CustomizedModel deleteCustomizedModel(
		com.liferay.discussion.test.model.CustomizedModel customizedModel) {
		return _customizedModelLocalService.deleteCustomizedModel(customizedModel);
	}

	/**
	* Deletes the customized model with the primary key from the database. Also notifies the appropriate model listeners.
	*
	* @param modelId the primary key of the customized model
	* @return the customized model that was removed
	* @throws PortalException if a customized model with the primary key could not be found
	*/
	@Override
	public com.liferay.discussion.test.model.CustomizedModel deleteCustomizedModel(
		long modelId)
		throws com.liferay.portal.kernel.exception.PortalException {
		return _customizedModelLocalService.deleteCustomizedModel(modelId);
	}

	@Override
	public com.liferay.discussion.test.model.CustomizedModel fetchCustomizedModel(
		long modelId) {
		return _customizedModelLocalService.fetchCustomizedModel(modelId);
	}

	/**
	* Returns the customized model matching the UUID and group.
	*
	* @param uuid the customized model's UUID
	* @param groupId the primary key of the group
	* @return the matching customized model, or <code>null</code> if a matching customized model could not be found
	*/
	@Override
	public com.liferay.discussion.test.model.CustomizedModel fetchCustomizedModelByUuidAndGroupId(
		java.lang.String uuid, long groupId) {
		return _customizedModelLocalService.fetchCustomizedModelByUuidAndGroupId(uuid,
			groupId);
	}

	/**
	* Returns the customized model with the primary key.
	*
	* @param modelId the primary key of the customized model
	* @return the customized model
	* @throws PortalException if a customized model with the primary key could not be found
	*/
	@Override
	public com.liferay.discussion.test.model.CustomizedModel getCustomizedModel(
		long modelId)
		throws com.liferay.portal.kernel.exception.PortalException {
		return _customizedModelLocalService.getCustomizedModel(modelId);
	}

	/**
	* Returns the customized model matching the UUID and group.
	*
	* @param uuid the customized model's UUID
	* @param groupId the primary key of the group
	* @return the matching customized model
	* @throws PortalException if a matching customized model could not be found
	*/
	@Override
	public com.liferay.discussion.test.model.CustomizedModel getCustomizedModelByUuidAndGroupId(
		java.lang.String uuid, long groupId)
		throws com.liferay.portal.kernel.exception.PortalException {
		return _customizedModelLocalService.getCustomizedModelByUuidAndGroupId(uuid,
			groupId);
	}

	/**
	* Updates the customized model in the database or adds it if it does not yet exist. Also notifies the appropriate model listeners.
	*
	* @param customizedModel the customized model
	* @return the customized model that was updated
	*/
	@Override
	public com.liferay.discussion.test.model.CustomizedModel updateCustomizedModel(
		com.liferay.discussion.test.model.CustomizedModel customizedModel) {
		return _customizedModelLocalService.updateCustomizedModel(customizedModel);
	}

	@Override
	public com.liferay.portal.kernel.dao.orm.ActionableDynamicQuery getActionableDynamicQuery() {
		return _customizedModelLocalService.getActionableDynamicQuery();
	}

	@Override
	public com.liferay.portal.kernel.dao.orm.DynamicQuery dynamicQuery() {
		return _customizedModelLocalService.dynamicQuery();
	}

	@Override
	public com.liferay.portal.kernel.dao.orm.IndexableActionableDynamicQuery getIndexableActionableDynamicQuery() {
		return _customizedModelLocalService.getIndexableActionableDynamicQuery();
	}

	/**
	* @throws PortalException
	*/
	@Override
	public com.liferay.portal.kernel.model.PersistedModel deletePersistedModel(
		com.liferay.portal.kernel.model.PersistedModel persistedModel)
		throws com.liferay.portal.kernel.exception.PortalException {
		return _customizedModelLocalService.deletePersistedModel(persistedModel);
	}

	@Override
	public com.liferay.portal.kernel.model.PersistedModel getPersistedModel(
		java.io.Serializable primaryKeyObj)
		throws com.liferay.portal.kernel.exception.PortalException {
		return _customizedModelLocalService.getPersistedModel(primaryKeyObj);
	}

	/**
	* Returns the number of customized models.
	*
	* @return the number of customized models
	*/
	@Override
	public int getCustomizedModelsCount() {
		return _customizedModelLocalService.getCustomizedModelsCount();
	}

	/**
	* Returns the OSGi service identifier.
	*
	* @return the OSGi service identifier
	*/
	@Override
	public java.lang.String getOSGiServiceIdentifier() {
		return _customizedModelLocalService.getOSGiServiceIdentifier();
	}

	/**
	* Performs a dynamic query on the database and returns the matching rows.
	*
	* @param dynamicQuery the dynamic query
	* @return the matching rows
	*/
	@Override
	public <T> java.util.List<T> dynamicQuery(
		com.liferay.portal.kernel.dao.orm.DynamicQuery dynamicQuery) {
		return _customizedModelLocalService.dynamicQuery(dynamicQuery);
	}

	/**
	* Performs a dynamic query on the database and returns a range of the matching rows.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.liferay.discussion.test.model.impl.CustomizedModelModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param dynamicQuery the dynamic query
	* @param start the lower bound of the range of model instances
	* @param end the upper bound of the range of model instances (not inclusive)
	* @return the range of matching rows
	*/
	@Override
	public <T> java.util.List<T> dynamicQuery(
		com.liferay.portal.kernel.dao.orm.DynamicQuery dynamicQuery, int start,
		int end) {
		return _customizedModelLocalService.dynamicQuery(dynamicQuery, start,
			end);
	}

	/**
	* Performs a dynamic query on the database and returns an ordered range of the matching rows.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.liferay.discussion.test.model.impl.CustomizedModelModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param dynamicQuery the dynamic query
	* @param start the lower bound of the range of model instances
	* @param end the upper bound of the range of model instances (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the ordered range of matching rows
	*/
	@Override
	public <T> java.util.List<T> dynamicQuery(
		com.liferay.portal.kernel.dao.orm.DynamicQuery dynamicQuery, int start,
		int end,
		com.liferay.portal.kernel.util.OrderByComparator<T> orderByComparator) {
		return _customizedModelLocalService.dynamicQuery(dynamicQuery, start,
			end, orderByComparator);
	}

	/**
	* Returns a range of all the customized models.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.liferay.discussion.test.model.impl.CustomizedModelModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param start the lower bound of the range of customized models
	* @param end the upper bound of the range of customized models (not inclusive)
	* @return the range of customized models
	*/
	@Override
	public java.util.List<com.liferay.discussion.test.model.CustomizedModel> getCustomizedModels(
		int start, int end) {
		return _customizedModelLocalService.getCustomizedModels(start, end);
	}

	/**
	* Returns all the customized models matching the UUID and company.
	*
	* @param uuid the UUID of the customized models
	* @param companyId the primary key of the company
	* @return the matching customized models, or an empty list if no matches were found
	*/
	@Override
	public java.util.List<com.liferay.discussion.test.model.CustomizedModel> getCustomizedModelsByUuidAndCompanyId(
		java.lang.String uuid, long companyId) {
		return _customizedModelLocalService.getCustomizedModelsByUuidAndCompanyId(uuid,
			companyId);
	}

	/**
	* Returns a range of customized models matching the UUID and company.
	*
	* @param uuid the UUID of the customized models
	* @param companyId the primary key of the company
	* @param start the lower bound of the range of customized models
	* @param end the upper bound of the range of customized models (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the range of matching customized models, or an empty list if no matches were found
	*/
	@Override
	public java.util.List<com.liferay.discussion.test.model.CustomizedModel> getCustomizedModelsByUuidAndCompanyId(
		java.lang.String uuid, long companyId, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator<com.liferay.discussion.test.model.CustomizedModel> orderByComparator) {
		return _customizedModelLocalService.getCustomizedModelsByUuidAndCompanyId(uuid,
			companyId, start, end, orderByComparator);
	}

	/**
	* Returns the number of rows matching the dynamic query.
	*
	* @param dynamicQuery the dynamic query
	* @return the number of rows matching the dynamic query
	*/
	@Override
	public long dynamicQueryCount(
		com.liferay.portal.kernel.dao.orm.DynamicQuery dynamicQuery) {
		return _customizedModelLocalService.dynamicQueryCount(dynamicQuery);
	}

	/**
	* Returns the number of rows matching the dynamic query.
	*
	* @param dynamicQuery the dynamic query
	* @param projection the projection to apply to the query
	* @return the number of rows matching the dynamic query
	*/
	@Override
	public long dynamicQueryCount(
		com.liferay.portal.kernel.dao.orm.DynamicQuery dynamicQuery,
		com.liferay.portal.kernel.dao.orm.Projection projection) {
		return _customizedModelLocalService.dynamicQueryCount(dynamicQuery,
			projection);
	}

	@Override
	public void deleteAll(long groupId)
		throws com.liferay.portal.kernel.exception.PortalException {
		_customizedModelLocalService.deleteAll(groupId);
	}

	@Override
	public CustomizedModelLocalService getWrappedService() {
		return _customizedModelLocalService;
	}

	@Override
	public void setWrappedService(
		CustomizedModelLocalService customizedModelLocalService) {
		_customizedModelLocalService = customizedModelLocalService;
	}

	private CustomizedModelLocalService _customizedModelLocalService;
}