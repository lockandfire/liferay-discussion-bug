/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.liferay.discussion.test.model;

import aQute.bnd.annotation.ProviderType;

import com.liferay.expando.kernel.model.ExpandoBridge;

import com.liferay.portal.kernel.model.ModelWrapper;
import com.liferay.portal.kernel.service.ServiceContext;

import java.io.Serializable;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.Objects;

/**
 * <p>
 * This class is a wrapper for {@link CustomizedModel}.
 * </p>
 *
 * @author Brian Wing Shun Chan
 * @see CustomizedModel
 * @generated
 */
@ProviderType
public class CustomizedModelWrapper implements CustomizedModel,
	ModelWrapper<CustomizedModel> {
	public CustomizedModelWrapper(CustomizedModel customizedModel) {
		_customizedModel = customizedModel;
	}

	@Override
	public Class<?> getModelClass() {
		return CustomizedModel.class;
	}

	@Override
	public String getModelClassName() {
		return CustomizedModel.class.getName();
	}

	@Override
	public Map<String, Object> getModelAttributes() {
		Map<String, Object> attributes = new HashMap<String, Object>();

		attributes.put("uuid", getUuid());
		attributes.put("modelId", getModelId());
		attributes.put("groupId", getGroupId());
		attributes.put("companyId", getCompanyId());
		attributes.put("userId", getUserId());
		attributes.put("userName", getUserName());
		attributes.put("createDate", getCreateDate());
		attributes.put("title", getTitle());
		attributes.put("body", getBody());
		attributes.put("status", getStatus());
		attributes.put("statusByUserId", getStatusByUserId());
		attributes.put("statusByUserName", getStatusByUserName());
		attributes.put("statusDate", getStatusDate());

		return attributes;
	}

	@Override
	public void setModelAttributes(Map<String, Object> attributes) {
		String uuid = (String)attributes.get("uuid");

		if (uuid != null) {
			setUuid(uuid);
		}

		Long modelId = (Long)attributes.get("modelId");

		if (modelId != null) {
			setModelId(modelId);
		}

		Long groupId = (Long)attributes.get("groupId");

		if (groupId != null) {
			setGroupId(groupId);
		}

		Long companyId = (Long)attributes.get("companyId");

		if (companyId != null) {
			setCompanyId(companyId);
		}

		Long userId = (Long)attributes.get("userId");

		if (userId != null) {
			setUserId(userId);
		}

		String userName = (String)attributes.get("userName");

		if (userName != null) {
			setUserName(userName);
		}

		Date createDate = (Date)attributes.get("createDate");

		if (createDate != null) {
			setCreateDate(createDate);
		}

		String title = (String)attributes.get("title");

		if (title != null) {
			setTitle(title);
		}

		String body = (String)attributes.get("body");

		if (body != null) {
			setBody(body);
		}

		Integer status = (Integer)attributes.get("status");

		if (status != null) {
			setStatus(status);
		}

		Long statusByUserId = (Long)attributes.get("statusByUserId");

		if (statusByUserId != null) {
			setStatusByUserId(statusByUserId);
		}

		String statusByUserName = (String)attributes.get("statusByUserName");

		if (statusByUserName != null) {
			setStatusByUserName(statusByUserName);
		}

		Date statusDate = (Date)attributes.get("statusDate");

		if (statusDate != null) {
			setStatusDate(statusDate);
		}
	}

	@Override
	public CustomizedModel toEscapedModel() {
		return new CustomizedModelWrapper(_customizedModel.toEscapedModel());
	}

	@Override
	public CustomizedModel toUnescapedModel() {
		return new CustomizedModelWrapper(_customizedModel.toUnescapedModel());
	}

	/**
	* Returns <code>true</code> if this customized model is approved.
	*
	* @return <code>true</code> if this customized model is approved; <code>false</code> otherwise
	*/
	@Override
	public boolean isApproved() {
		return _customizedModel.isApproved();
	}

	@Override
	public boolean isCachedModel() {
		return _customizedModel.isCachedModel();
	}

	/**
	* Returns <code>true</code> if this customized model is denied.
	*
	* @return <code>true</code> if this customized model is denied; <code>false</code> otherwise
	*/
	@Override
	public boolean isDenied() {
		return _customizedModel.isDenied();
	}

	/**
	* Returns <code>true</code> if this customized model is a draft.
	*
	* @return <code>true</code> if this customized model is a draft; <code>false</code> otherwise
	*/
	@Override
	public boolean isDraft() {
		return _customizedModel.isDraft();
	}

	@Override
	public boolean isEscapedModel() {
		return _customizedModel.isEscapedModel();
	}

	/**
	* Returns <code>true</code> if this customized model is expired.
	*
	* @return <code>true</code> if this customized model is expired; <code>false</code> otherwise
	*/
	@Override
	public boolean isExpired() {
		return _customizedModel.isExpired();
	}

	/**
	* Returns <code>true</code> if this customized model is inactive.
	*
	* @return <code>true</code> if this customized model is inactive; <code>false</code> otherwise
	*/
	@Override
	public boolean isInactive() {
		return _customizedModel.isInactive();
	}

	/**
	* Returns <code>true</code> if this customized model is incomplete.
	*
	* @return <code>true</code> if this customized model is incomplete; <code>false</code> otherwise
	*/
	@Override
	public boolean isIncomplete() {
		return _customizedModel.isIncomplete();
	}

	@Override
	public boolean isNew() {
		return _customizedModel.isNew();
	}

	/**
	* Returns <code>true</code> if this customized model is pending.
	*
	* @return <code>true</code> if this customized model is pending; <code>false</code> otherwise
	*/
	@Override
	public boolean isPending() {
		return _customizedModel.isPending();
	}

	/**
	* Returns <code>true</code> if this customized model is scheduled.
	*
	* @return <code>true</code> if this customized model is scheduled; <code>false</code> otherwise
	*/
	@Override
	public boolean isScheduled() {
		return _customizedModel.isScheduled();
	}

	@Override
	public ExpandoBridge getExpandoBridge() {
		return _customizedModel.getExpandoBridge();
	}

	@Override
	public com.liferay.portal.kernel.model.CacheModel<CustomizedModel> toCacheModel() {
		return _customizedModel.toCacheModel();
	}

	@Override
	public int compareTo(CustomizedModel customizedModel) {
		return _customizedModel.compareTo(customizedModel);
	}

	/**
	* Returns the status of this customized model.
	*
	* @return the status of this customized model
	*/
	@Override
	public int getStatus() {
		return _customizedModel.getStatus();
	}

	@Override
	public int hashCode() {
		return _customizedModel.hashCode();
	}

	@Override
	public Serializable getPrimaryKeyObj() {
		return _customizedModel.getPrimaryKeyObj();
	}

	@Override
	public java.lang.Object clone() {
		return new CustomizedModelWrapper((CustomizedModel)_customizedModel.clone());
	}

	/**
	* Returns the body of this customized model.
	*
	* @return the body of this customized model
	*/
	@Override
	public java.lang.String getBody() {
		return _customizedModel.getBody();
	}

	/**
	* Returns the status by user name of this customized model.
	*
	* @return the status by user name of this customized model
	*/
	@Override
	public java.lang.String getStatusByUserName() {
		return _customizedModel.getStatusByUserName();
	}

	/**
	* Returns the status by user uuid of this customized model.
	*
	* @return the status by user uuid of this customized model
	*/
	@Override
	public java.lang.String getStatusByUserUuid() {
		return _customizedModel.getStatusByUserUuid();
	}

	/**
	* Returns the title of this customized model.
	*
	* @return the title of this customized model
	*/
	@Override
	public java.lang.String getTitle() {
		return _customizedModel.getTitle();
	}

	/**
	* Returns the user name of this customized model.
	*
	* @return the user name of this customized model
	*/
	@Override
	public java.lang.String getUserName() {
		return _customizedModel.getUserName();
	}

	/**
	* Returns the user uuid of this customized model.
	*
	* @return the user uuid of this customized model
	*/
	@Override
	public java.lang.String getUserUuid() {
		return _customizedModel.getUserUuid();
	}

	/**
	* Returns the uuid of this customized model.
	*
	* @return the uuid of this customized model
	*/
	@Override
	public java.lang.String getUuid() {
		return _customizedModel.getUuid();
	}

	@Override
	public java.lang.String toString() {
		return _customizedModel.toString();
	}

	@Override
	public java.lang.String toXmlString() {
		return _customizedModel.toXmlString();
	}

	/**
	* Returns the create date of this customized model.
	*
	* @return the create date of this customized model
	*/
	@Override
	public Date getCreateDate() {
		return _customizedModel.getCreateDate();
	}

	/**
	* Returns the status date of this customized model.
	*
	* @return the status date of this customized model
	*/
	@Override
	public Date getStatusDate() {
		return _customizedModel.getStatusDate();
	}

	/**
	* Returns the company ID of this customized model.
	*
	* @return the company ID of this customized model
	*/
	@Override
	public long getCompanyId() {
		return _customizedModel.getCompanyId();
	}

	/**
	* Returns the group ID of this customized model.
	*
	* @return the group ID of this customized model
	*/
	@Override
	public long getGroupId() {
		return _customizedModel.getGroupId();
	}

	/**
	* Returns the model ID of this customized model.
	*
	* @return the model ID of this customized model
	*/
	@Override
	public long getModelId() {
		return _customizedModel.getModelId();
	}

	/**
	* Returns the primary key of this customized model.
	*
	* @return the primary key of this customized model
	*/
	@Override
	public long getPrimaryKey() {
		return _customizedModel.getPrimaryKey();
	}

	/**
	* Returns the status by user ID of this customized model.
	*
	* @return the status by user ID of this customized model
	*/
	@Override
	public long getStatusByUserId() {
		return _customizedModel.getStatusByUserId();
	}

	/**
	* Returns the user ID of this customized model.
	*
	* @return the user ID of this customized model
	*/
	@Override
	public long getUserId() {
		return _customizedModel.getUserId();
	}

	@Override
	public void persist() {
		_customizedModel.persist();
	}

	/**
	* Sets the body of this customized model.
	*
	* @param body the body of this customized model
	*/
	@Override
	public void setBody(java.lang.String body) {
		_customizedModel.setBody(body);
	}

	@Override
	public void setCachedModel(boolean cachedModel) {
		_customizedModel.setCachedModel(cachedModel);
	}

	/**
	* Sets the company ID of this customized model.
	*
	* @param companyId the company ID of this customized model
	*/
	@Override
	public void setCompanyId(long companyId) {
		_customizedModel.setCompanyId(companyId);
	}

	/**
	* Sets the create date of this customized model.
	*
	* @param createDate the create date of this customized model
	*/
	@Override
	public void setCreateDate(Date createDate) {
		_customizedModel.setCreateDate(createDate);
	}

	@Override
	public void setExpandoBridgeAttributes(ExpandoBridge expandoBridge) {
		_customizedModel.setExpandoBridgeAttributes(expandoBridge);
	}

	@Override
	public void setExpandoBridgeAttributes(
		com.liferay.portal.kernel.model.BaseModel<?> baseModel) {
		_customizedModel.setExpandoBridgeAttributes(baseModel);
	}

	@Override
	public void setExpandoBridgeAttributes(ServiceContext serviceContext) {
		_customizedModel.setExpandoBridgeAttributes(serviceContext);
	}

	/**
	* Sets the group ID of this customized model.
	*
	* @param groupId the group ID of this customized model
	*/
	@Override
	public void setGroupId(long groupId) {
		_customizedModel.setGroupId(groupId);
	}

	/**
	* Sets the model ID of this customized model.
	*
	* @param modelId the model ID of this customized model
	*/
	@Override
	public void setModelId(long modelId) {
		_customizedModel.setModelId(modelId);
	}

	@Override
	public void setNew(boolean n) {
		_customizedModel.setNew(n);
	}

	/**
	* Sets the primary key of this customized model.
	*
	* @param primaryKey the primary key of this customized model
	*/
	@Override
	public void setPrimaryKey(long primaryKey) {
		_customizedModel.setPrimaryKey(primaryKey);
	}

	@Override
	public void setPrimaryKeyObj(Serializable primaryKeyObj) {
		_customizedModel.setPrimaryKeyObj(primaryKeyObj);
	}

	/**
	* Sets the status of this customized model.
	*
	* @param status the status of this customized model
	*/
	@Override
	public void setStatus(int status) {
		_customizedModel.setStatus(status);
	}

	/**
	* Sets the status by user ID of this customized model.
	*
	* @param statusByUserId the status by user ID of this customized model
	*/
	@Override
	public void setStatusByUserId(long statusByUserId) {
		_customizedModel.setStatusByUserId(statusByUserId);
	}

	/**
	* Sets the status by user name of this customized model.
	*
	* @param statusByUserName the status by user name of this customized model
	*/
	@Override
	public void setStatusByUserName(java.lang.String statusByUserName) {
		_customizedModel.setStatusByUserName(statusByUserName);
	}

	/**
	* Sets the status by user uuid of this customized model.
	*
	* @param statusByUserUuid the status by user uuid of this customized model
	*/
	@Override
	public void setStatusByUserUuid(java.lang.String statusByUserUuid) {
		_customizedModel.setStatusByUserUuid(statusByUserUuid);
	}

	/**
	* Sets the status date of this customized model.
	*
	* @param statusDate the status date of this customized model
	*/
	@Override
	public void setStatusDate(Date statusDate) {
		_customizedModel.setStatusDate(statusDate);
	}

	/**
	* Sets the title of this customized model.
	*
	* @param title the title of this customized model
	*/
	@Override
	public void setTitle(java.lang.String title) {
		_customizedModel.setTitle(title);
	}

	/**
	* Sets the user ID of this customized model.
	*
	* @param userId the user ID of this customized model
	*/
	@Override
	public void setUserId(long userId) {
		_customizedModel.setUserId(userId);
	}

	/**
	* Sets the user name of this customized model.
	*
	* @param userName the user name of this customized model
	*/
	@Override
	public void setUserName(java.lang.String userName) {
		_customizedModel.setUserName(userName);
	}

	/**
	* Sets the user uuid of this customized model.
	*
	* @param userUuid the user uuid of this customized model
	*/
	@Override
	public void setUserUuid(java.lang.String userUuid) {
		_customizedModel.setUserUuid(userUuid);
	}

	/**
	* Sets the uuid of this customized model.
	*
	* @param uuid the uuid of this customized model
	*/
	@Override
	public void setUuid(java.lang.String uuid) {
		_customizedModel.setUuid(uuid);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}

		if (!(obj instanceof CustomizedModelWrapper)) {
			return false;
		}

		CustomizedModelWrapper customizedModelWrapper = (CustomizedModelWrapper)obj;

		if (Objects.equals(_customizedModel,
					customizedModelWrapper._customizedModel)) {
			return true;
		}

		return false;
	}

	@Override
	public CustomizedModel getWrappedModel() {
		return _customizedModel;
	}

	@Override
	public boolean isEntityCacheEnabled() {
		return _customizedModel.isEntityCacheEnabled();
	}

	@Override
	public boolean isFinderCacheEnabled() {
		return _customizedModel.isFinderCacheEnabled();
	}

	@Override
	public void resetOriginalValues() {
		_customizedModel.resetOriginalValues();
	}

	private final CustomizedModel _customizedModel;
}