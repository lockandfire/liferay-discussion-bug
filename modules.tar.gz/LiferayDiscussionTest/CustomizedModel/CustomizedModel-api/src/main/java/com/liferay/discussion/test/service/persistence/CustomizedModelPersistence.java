/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.liferay.discussion.test.service.persistence;

import aQute.bnd.annotation.ProviderType;

import com.liferay.discussion.test.exception.NoSuchCustomizedModelException;
import com.liferay.discussion.test.model.CustomizedModel;

import com.liferay.portal.kernel.service.persistence.BasePersistence;

/**
 * The persistence interface for the customized model service.
 *
 * <p>
 * Caching information and settings can be found in <code>portal.properties</code>
 * </p>
 *
 * @author Brian Wing Shun Chan
 * @see com.liferay.discussion.test.service.persistence.impl.CustomizedModelPersistenceImpl
 * @see CustomizedModelUtil
 * @generated
 */
@ProviderType
public interface CustomizedModelPersistence extends BasePersistence<CustomizedModel> {
	/*
	 * NOTE FOR DEVELOPERS:
	 *
	 * Never modify or reference this interface directly. Always use {@link CustomizedModelUtil} to access the customized model persistence. Modify <code>service.xml</code> and rerun ServiceBuilder to regenerate this interface.
	 */

	/**
	* Returns all the customized models where uuid = &#63;.
	*
	* @param uuid the uuid
	* @return the matching customized models
	*/
	public java.util.List<CustomizedModel> findByUuid(java.lang.String uuid);

	/**
	* Returns a range of all the customized models where uuid = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link CustomizedModelModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param uuid the uuid
	* @param start the lower bound of the range of customized models
	* @param end the upper bound of the range of customized models (not inclusive)
	* @return the range of matching customized models
	*/
	public java.util.List<CustomizedModel> findByUuid(java.lang.String uuid,
		int start, int end);

	/**
	* Returns an ordered range of all the customized models where uuid = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link CustomizedModelModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param uuid the uuid
	* @param start the lower bound of the range of customized models
	* @param end the upper bound of the range of customized models (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the ordered range of matching customized models
	*/
	public java.util.List<CustomizedModel> findByUuid(java.lang.String uuid,
		int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator<CustomizedModel> orderByComparator);

	/**
	* Returns an ordered range of all the customized models where uuid = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link CustomizedModelModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param uuid the uuid
	* @param start the lower bound of the range of customized models
	* @param end the upper bound of the range of customized models (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @param retrieveFromCache whether to retrieve from the finder cache
	* @return the ordered range of matching customized models
	*/
	public java.util.List<CustomizedModel> findByUuid(java.lang.String uuid,
		int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator<CustomizedModel> orderByComparator,
		boolean retrieveFromCache);

	/**
	* Returns the first customized model in the ordered set where uuid = &#63;.
	*
	* @param uuid the uuid
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching customized model
	* @throws NoSuchCustomizedModelException if a matching customized model could not be found
	*/
	public CustomizedModel findByUuid_First(java.lang.String uuid,
		com.liferay.portal.kernel.util.OrderByComparator<CustomizedModel> orderByComparator)
		throws NoSuchCustomizedModelException;

	/**
	* Returns the first customized model in the ordered set where uuid = &#63;.
	*
	* @param uuid the uuid
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching customized model, or <code>null</code> if a matching customized model could not be found
	*/
	public CustomizedModel fetchByUuid_First(java.lang.String uuid,
		com.liferay.portal.kernel.util.OrderByComparator<CustomizedModel> orderByComparator);

	/**
	* Returns the last customized model in the ordered set where uuid = &#63;.
	*
	* @param uuid the uuid
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching customized model
	* @throws NoSuchCustomizedModelException if a matching customized model could not be found
	*/
	public CustomizedModel findByUuid_Last(java.lang.String uuid,
		com.liferay.portal.kernel.util.OrderByComparator<CustomizedModel> orderByComparator)
		throws NoSuchCustomizedModelException;

	/**
	* Returns the last customized model in the ordered set where uuid = &#63;.
	*
	* @param uuid the uuid
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching customized model, or <code>null</code> if a matching customized model could not be found
	*/
	public CustomizedModel fetchByUuid_Last(java.lang.String uuid,
		com.liferay.portal.kernel.util.OrderByComparator<CustomizedModel> orderByComparator);

	/**
	* Returns the customized models before and after the current customized model in the ordered set where uuid = &#63;.
	*
	* @param modelId the primary key of the current customized model
	* @param uuid the uuid
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the previous, current, and next customized model
	* @throws NoSuchCustomizedModelException if a customized model with the primary key could not be found
	*/
	public CustomizedModel[] findByUuid_PrevAndNext(long modelId,
		java.lang.String uuid,
		com.liferay.portal.kernel.util.OrderByComparator<CustomizedModel> orderByComparator)
		throws NoSuchCustomizedModelException;

	/**
	* Removes all the customized models where uuid = &#63; from the database.
	*
	* @param uuid the uuid
	*/
	public void removeByUuid(java.lang.String uuid);

	/**
	* Returns the number of customized models where uuid = &#63;.
	*
	* @param uuid the uuid
	* @return the number of matching customized models
	*/
	public int countByUuid(java.lang.String uuid);

	/**
	* Returns the customized model where uuid = &#63; and groupId = &#63; or throws a {@link NoSuchCustomizedModelException} if it could not be found.
	*
	* @param uuid the uuid
	* @param groupId the group ID
	* @return the matching customized model
	* @throws NoSuchCustomizedModelException if a matching customized model could not be found
	*/
	public CustomizedModel findByUUID_G(java.lang.String uuid, long groupId)
		throws NoSuchCustomizedModelException;

	/**
	* Returns the customized model where uuid = &#63; and groupId = &#63; or returns <code>null</code> if it could not be found. Uses the finder cache.
	*
	* @param uuid the uuid
	* @param groupId the group ID
	* @return the matching customized model, or <code>null</code> if a matching customized model could not be found
	*/
	public CustomizedModel fetchByUUID_G(java.lang.String uuid, long groupId);

	/**
	* Returns the customized model where uuid = &#63; and groupId = &#63; or returns <code>null</code> if it could not be found, optionally using the finder cache.
	*
	* @param uuid the uuid
	* @param groupId the group ID
	* @param retrieveFromCache whether to retrieve from the finder cache
	* @return the matching customized model, or <code>null</code> if a matching customized model could not be found
	*/
	public CustomizedModel fetchByUUID_G(java.lang.String uuid, long groupId,
		boolean retrieveFromCache);

	/**
	* Removes the customized model where uuid = &#63; and groupId = &#63; from the database.
	*
	* @param uuid the uuid
	* @param groupId the group ID
	* @return the customized model that was removed
	*/
	public CustomizedModel removeByUUID_G(java.lang.String uuid, long groupId)
		throws NoSuchCustomizedModelException;

	/**
	* Returns the number of customized models where uuid = &#63; and groupId = &#63;.
	*
	* @param uuid the uuid
	* @param groupId the group ID
	* @return the number of matching customized models
	*/
	public int countByUUID_G(java.lang.String uuid, long groupId);

	/**
	* Returns all the customized models where uuid = &#63; and companyId = &#63;.
	*
	* @param uuid the uuid
	* @param companyId the company ID
	* @return the matching customized models
	*/
	public java.util.List<CustomizedModel> findByUuid_C(java.lang.String uuid,
		long companyId);

	/**
	* Returns a range of all the customized models where uuid = &#63; and companyId = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link CustomizedModelModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param uuid the uuid
	* @param companyId the company ID
	* @param start the lower bound of the range of customized models
	* @param end the upper bound of the range of customized models (not inclusive)
	* @return the range of matching customized models
	*/
	public java.util.List<CustomizedModel> findByUuid_C(java.lang.String uuid,
		long companyId, int start, int end);

	/**
	* Returns an ordered range of all the customized models where uuid = &#63; and companyId = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link CustomizedModelModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param uuid the uuid
	* @param companyId the company ID
	* @param start the lower bound of the range of customized models
	* @param end the upper bound of the range of customized models (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the ordered range of matching customized models
	*/
	public java.util.List<CustomizedModel> findByUuid_C(java.lang.String uuid,
		long companyId, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator<CustomizedModel> orderByComparator);

	/**
	* Returns an ordered range of all the customized models where uuid = &#63; and companyId = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link CustomizedModelModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param uuid the uuid
	* @param companyId the company ID
	* @param start the lower bound of the range of customized models
	* @param end the upper bound of the range of customized models (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @param retrieveFromCache whether to retrieve from the finder cache
	* @return the ordered range of matching customized models
	*/
	public java.util.List<CustomizedModel> findByUuid_C(java.lang.String uuid,
		long companyId, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator<CustomizedModel> orderByComparator,
		boolean retrieveFromCache);

	/**
	* Returns the first customized model in the ordered set where uuid = &#63; and companyId = &#63;.
	*
	* @param uuid the uuid
	* @param companyId the company ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching customized model
	* @throws NoSuchCustomizedModelException if a matching customized model could not be found
	*/
	public CustomizedModel findByUuid_C_First(java.lang.String uuid,
		long companyId,
		com.liferay.portal.kernel.util.OrderByComparator<CustomizedModel> orderByComparator)
		throws NoSuchCustomizedModelException;

	/**
	* Returns the first customized model in the ordered set where uuid = &#63; and companyId = &#63;.
	*
	* @param uuid the uuid
	* @param companyId the company ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching customized model, or <code>null</code> if a matching customized model could not be found
	*/
	public CustomizedModel fetchByUuid_C_First(java.lang.String uuid,
		long companyId,
		com.liferay.portal.kernel.util.OrderByComparator<CustomizedModel> orderByComparator);

	/**
	* Returns the last customized model in the ordered set where uuid = &#63; and companyId = &#63;.
	*
	* @param uuid the uuid
	* @param companyId the company ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching customized model
	* @throws NoSuchCustomizedModelException if a matching customized model could not be found
	*/
	public CustomizedModel findByUuid_C_Last(java.lang.String uuid,
		long companyId,
		com.liferay.portal.kernel.util.OrderByComparator<CustomizedModel> orderByComparator)
		throws NoSuchCustomizedModelException;

	/**
	* Returns the last customized model in the ordered set where uuid = &#63; and companyId = &#63;.
	*
	* @param uuid the uuid
	* @param companyId the company ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching customized model, or <code>null</code> if a matching customized model could not be found
	*/
	public CustomizedModel fetchByUuid_C_Last(java.lang.String uuid,
		long companyId,
		com.liferay.portal.kernel.util.OrderByComparator<CustomizedModel> orderByComparator);

	/**
	* Returns the customized models before and after the current customized model in the ordered set where uuid = &#63; and companyId = &#63;.
	*
	* @param modelId the primary key of the current customized model
	* @param uuid the uuid
	* @param companyId the company ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the previous, current, and next customized model
	* @throws NoSuchCustomizedModelException if a customized model with the primary key could not be found
	*/
	public CustomizedModel[] findByUuid_C_PrevAndNext(long modelId,
		java.lang.String uuid, long companyId,
		com.liferay.portal.kernel.util.OrderByComparator<CustomizedModel> orderByComparator)
		throws NoSuchCustomizedModelException;

	/**
	* Removes all the customized models where uuid = &#63; and companyId = &#63; from the database.
	*
	* @param uuid the uuid
	* @param companyId the company ID
	*/
	public void removeByUuid_C(java.lang.String uuid, long companyId);

	/**
	* Returns the number of customized models where uuid = &#63; and companyId = &#63;.
	*
	* @param uuid the uuid
	* @param companyId the company ID
	* @return the number of matching customized models
	*/
	public int countByUuid_C(java.lang.String uuid, long companyId);

	/**
	* Returns all the customized models where status = &#63;.
	*
	* @param status the status
	* @return the matching customized models
	*/
	public java.util.List<CustomizedModel> findByStatus(int status);

	/**
	* Returns a range of all the customized models where status = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link CustomizedModelModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param status the status
	* @param start the lower bound of the range of customized models
	* @param end the upper bound of the range of customized models (not inclusive)
	* @return the range of matching customized models
	*/
	public java.util.List<CustomizedModel> findByStatus(int status, int start,
		int end);

	/**
	* Returns an ordered range of all the customized models where status = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link CustomizedModelModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param status the status
	* @param start the lower bound of the range of customized models
	* @param end the upper bound of the range of customized models (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the ordered range of matching customized models
	*/
	public java.util.List<CustomizedModel> findByStatus(int status, int start,
		int end,
		com.liferay.portal.kernel.util.OrderByComparator<CustomizedModel> orderByComparator);

	/**
	* Returns an ordered range of all the customized models where status = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link CustomizedModelModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param status the status
	* @param start the lower bound of the range of customized models
	* @param end the upper bound of the range of customized models (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @param retrieveFromCache whether to retrieve from the finder cache
	* @return the ordered range of matching customized models
	*/
	public java.util.List<CustomizedModel> findByStatus(int status, int start,
		int end,
		com.liferay.portal.kernel.util.OrderByComparator<CustomizedModel> orderByComparator,
		boolean retrieveFromCache);

	/**
	* Returns the first customized model in the ordered set where status = &#63;.
	*
	* @param status the status
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching customized model
	* @throws NoSuchCustomizedModelException if a matching customized model could not be found
	*/
	public CustomizedModel findByStatus_First(int status,
		com.liferay.portal.kernel.util.OrderByComparator<CustomizedModel> orderByComparator)
		throws NoSuchCustomizedModelException;

	/**
	* Returns the first customized model in the ordered set where status = &#63;.
	*
	* @param status the status
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching customized model, or <code>null</code> if a matching customized model could not be found
	*/
	public CustomizedModel fetchByStatus_First(int status,
		com.liferay.portal.kernel.util.OrderByComparator<CustomizedModel> orderByComparator);

	/**
	* Returns the last customized model in the ordered set where status = &#63;.
	*
	* @param status the status
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching customized model
	* @throws NoSuchCustomizedModelException if a matching customized model could not be found
	*/
	public CustomizedModel findByStatus_Last(int status,
		com.liferay.portal.kernel.util.OrderByComparator<CustomizedModel> orderByComparator)
		throws NoSuchCustomizedModelException;

	/**
	* Returns the last customized model in the ordered set where status = &#63;.
	*
	* @param status the status
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching customized model, or <code>null</code> if a matching customized model could not be found
	*/
	public CustomizedModel fetchByStatus_Last(int status,
		com.liferay.portal.kernel.util.OrderByComparator<CustomizedModel> orderByComparator);

	/**
	* Returns the customized models before and after the current customized model in the ordered set where status = &#63;.
	*
	* @param modelId the primary key of the current customized model
	* @param status the status
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the previous, current, and next customized model
	* @throws NoSuchCustomizedModelException if a customized model with the primary key could not be found
	*/
	public CustomizedModel[] findByStatus_PrevAndNext(long modelId, int status,
		com.liferay.portal.kernel.util.OrderByComparator<CustomizedModel> orderByComparator)
		throws NoSuchCustomizedModelException;

	/**
	* Removes all the customized models where status = &#63; from the database.
	*
	* @param status the status
	*/
	public void removeByStatus(int status);

	/**
	* Returns the number of customized models where status = &#63;.
	*
	* @param status the status
	* @return the number of matching customized models
	*/
	public int countByStatus(int status);

	/**
	* Returns all the customized models where groupId = &#63; and status = &#63;.
	*
	* @param groupId the group ID
	* @param status the status
	* @return the matching customized models
	*/
	public java.util.List<CustomizedModel> findByGroupAndStatus(long groupId,
		int status);

	/**
	* Returns a range of all the customized models where groupId = &#63; and status = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link CustomizedModelModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param groupId the group ID
	* @param status the status
	* @param start the lower bound of the range of customized models
	* @param end the upper bound of the range of customized models (not inclusive)
	* @return the range of matching customized models
	*/
	public java.util.List<CustomizedModel> findByGroupAndStatus(long groupId,
		int status, int start, int end);

	/**
	* Returns an ordered range of all the customized models where groupId = &#63; and status = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link CustomizedModelModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param groupId the group ID
	* @param status the status
	* @param start the lower bound of the range of customized models
	* @param end the upper bound of the range of customized models (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the ordered range of matching customized models
	*/
	public java.util.List<CustomizedModel> findByGroupAndStatus(long groupId,
		int status, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator<CustomizedModel> orderByComparator);

	/**
	* Returns an ordered range of all the customized models where groupId = &#63; and status = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link CustomizedModelModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param groupId the group ID
	* @param status the status
	* @param start the lower bound of the range of customized models
	* @param end the upper bound of the range of customized models (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @param retrieveFromCache whether to retrieve from the finder cache
	* @return the ordered range of matching customized models
	*/
	public java.util.List<CustomizedModel> findByGroupAndStatus(long groupId,
		int status, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator<CustomizedModel> orderByComparator,
		boolean retrieveFromCache);

	/**
	* Returns the first customized model in the ordered set where groupId = &#63; and status = &#63;.
	*
	* @param groupId the group ID
	* @param status the status
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching customized model
	* @throws NoSuchCustomizedModelException if a matching customized model could not be found
	*/
	public CustomizedModel findByGroupAndStatus_First(long groupId, int status,
		com.liferay.portal.kernel.util.OrderByComparator<CustomizedModel> orderByComparator)
		throws NoSuchCustomizedModelException;

	/**
	* Returns the first customized model in the ordered set where groupId = &#63; and status = &#63;.
	*
	* @param groupId the group ID
	* @param status the status
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching customized model, or <code>null</code> if a matching customized model could not be found
	*/
	public CustomizedModel fetchByGroupAndStatus_First(long groupId,
		int status,
		com.liferay.portal.kernel.util.OrderByComparator<CustomizedModel> orderByComparator);

	/**
	* Returns the last customized model in the ordered set where groupId = &#63; and status = &#63;.
	*
	* @param groupId the group ID
	* @param status the status
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching customized model
	* @throws NoSuchCustomizedModelException if a matching customized model could not be found
	*/
	public CustomizedModel findByGroupAndStatus_Last(long groupId, int status,
		com.liferay.portal.kernel.util.OrderByComparator<CustomizedModel> orderByComparator)
		throws NoSuchCustomizedModelException;

	/**
	* Returns the last customized model in the ordered set where groupId = &#63; and status = &#63;.
	*
	* @param groupId the group ID
	* @param status the status
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching customized model, or <code>null</code> if a matching customized model could not be found
	*/
	public CustomizedModel fetchByGroupAndStatus_Last(long groupId, int status,
		com.liferay.portal.kernel.util.OrderByComparator<CustomizedModel> orderByComparator);

	/**
	* Returns the customized models before and after the current customized model in the ordered set where groupId = &#63; and status = &#63;.
	*
	* @param modelId the primary key of the current customized model
	* @param groupId the group ID
	* @param status the status
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the previous, current, and next customized model
	* @throws NoSuchCustomizedModelException if a customized model with the primary key could not be found
	*/
	public CustomizedModel[] findByGroupAndStatus_PrevAndNext(long modelId,
		long groupId, int status,
		com.liferay.portal.kernel.util.OrderByComparator<CustomizedModel> orderByComparator)
		throws NoSuchCustomizedModelException;

	/**
	* Returns all the customized models that the user has permission to view where groupId = &#63; and status = &#63;.
	*
	* @param groupId the group ID
	* @param status the status
	* @return the matching customized models that the user has permission to view
	*/
	public java.util.List<CustomizedModel> filterFindByGroupAndStatus(
		long groupId, int status);

	/**
	* Returns a range of all the customized models that the user has permission to view where groupId = &#63; and status = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link CustomizedModelModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param groupId the group ID
	* @param status the status
	* @param start the lower bound of the range of customized models
	* @param end the upper bound of the range of customized models (not inclusive)
	* @return the range of matching customized models that the user has permission to view
	*/
	public java.util.List<CustomizedModel> filterFindByGroupAndStatus(
		long groupId, int status, int start, int end);

	/**
	* Returns an ordered range of all the customized models that the user has permissions to view where groupId = &#63; and status = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link CustomizedModelModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param groupId the group ID
	* @param status the status
	* @param start the lower bound of the range of customized models
	* @param end the upper bound of the range of customized models (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the ordered range of matching customized models that the user has permission to view
	*/
	public java.util.List<CustomizedModel> filterFindByGroupAndStatus(
		long groupId, int status, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator<CustomizedModel> orderByComparator);

	/**
	* Returns the customized models before and after the current customized model in the ordered set of customized models that the user has permission to view where groupId = &#63; and status = &#63;.
	*
	* @param modelId the primary key of the current customized model
	* @param groupId the group ID
	* @param status the status
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the previous, current, and next customized model
	* @throws NoSuchCustomizedModelException if a customized model with the primary key could not be found
	*/
	public CustomizedModel[] filterFindByGroupAndStatus_PrevAndNext(
		long modelId, long groupId, int status,
		com.liferay.portal.kernel.util.OrderByComparator<CustomizedModel> orderByComparator)
		throws NoSuchCustomizedModelException;

	/**
	* Removes all the customized models where groupId = &#63; and status = &#63; from the database.
	*
	* @param groupId the group ID
	* @param status the status
	*/
	public void removeByGroupAndStatus(long groupId, int status);

	/**
	* Returns the number of customized models where groupId = &#63; and status = &#63;.
	*
	* @param groupId the group ID
	* @param status the status
	* @return the number of matching customized models
	*/
	public int countByGroupAndStatus(long groupId, int status);

	/**
	* Returns the number of customized models that the user has permission to view where groupId = &#63; and status = &#63;.
	*
	* @param groupId the group ID
	* @param status the status
	* @return the number of matching customized models that the user has permission to view
	*/
	public int filterCountByGroupAndStatus(long groupId, int status);

	/**
	* Caches the customized model in the entity cache if it is enabled.
	*
	* @param customizedModel the customized model
	*/
	public void cacheResult(CustomizedModel customizedModel);

	/**
	* Caches the customized models in the entity cache if it is enabled.
	*
	* @param customizedModels the customized models
	*/
	public void cacheResult(java.util.List<CustomizedModel> customizedModels);

	/**
	* Creates a new customized model with the primary key. Does not add the customized model to the database.
	*
	* @param modelId the primary key for the new customized model
	* @return the new customized model
	*/
	public CustomizedModel create(long modelId);

	/**
	* Removes the customized model with the primary key from the database. Also notifies the appropriate model listeners.
	*
	* @param modelId the primary key of the customized model
	* @return the customized model that was removed
	* @throws NoSuchCustomizedModelException if a customized model with the primary key could not be found
	*/
	public CustomizedModel remove(long modelId)
		throws NoSuchCustomizedModelException;

	public CustomizedModel updateImpl(CustomizedModel customizedModel);

	/**
	* Returns the customized model with the primary key or throws a {@link NoSuchCustomizedModelException} if it could not be found.
	*
	* @param modelId the primary key of the customized model
	* @return the customized model
	* @throws NoSuchCustomizedModelException if a customized model with the primary key could not be found
	*/
	public CustomizedModel findByPrimaryKey(long modelId)
		throws NoSuchCustomizedModelException;

	/**
	* Returns the customized model with the primary key or returns <code>null</code> if it could not be found.
	*
	* @param modelId the primary key of the customized model
	* @return the customized model, or <code>null</code> if a customized model with the primary key could not be found
	*/
	public CustomizedModel fetchByPrimaryKey(long modelId);

	@Override
	public java.util.Map<java.io.Serializable, CustomizedModel> fetchByPrimaryKeys(
		java.util.Set<java.io.Serializable> primaryKeys);

	/**
	* Returns all the customized models.
	*
	* @return the customized models
	*/
	public java.util.List<CustomizedModel> findAll();

	/**
	* Returns a range of all the customized models.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link CustomizedModelModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param start the lower bound of the range of customized models
	* @param end the upper bound of the range of customized models (not inclusive)
	* @return the range of customized models
	*/
	public java.util.List<CustomizedModel> findAll(int start, int end);

	/**
	* Returns an ordered range of all the customized models.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link CustomizedModelModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param start the lower bound of the range of customized models
	* @param end the upper bound of the range of customized models (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the ordered range of customized models
	*/
	public java.util.List<CustomizedModel> findAll(int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator<CustomizedModel> orderByComparator);

	/**
	* Returns an ordered range of all the customized models.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link CustomizedModelModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param start the lower bound of the range of customized models
	* @param end the upper bound of the range of customized models (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @param retrieveFromCache whether to retrieve from the finder cache
	* @return the ordered range of customized models
	*/
	public java.util.List<CustomizedModel> findAll(int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator<CustomizedModel> orderByComparator,
		boolean retrieveFromCache);

	/**
	* Removes all the customized models from the database.
	*/
	public void removeAll();

	/**
	* Returns the number of customized models.
	*
	* @return the number of customized models
	*/
	public int countAll();

	@Override
	public java.util.Set<java.lang.String> getBadColumnNames();
}