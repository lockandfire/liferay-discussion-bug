/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.liferay.discussion.test.service.persistence;

import aQute.bnd.annotation.ProviderType;

import com.liferay.discussion.test.model.CustomizedModel;

import com.liferay.osgi.util.ServiceTrackerFactory;

import com.liferay.portal.kernel.dao.orm.DynamicQuery;
import com.liferay.portal.kernel.service.ServiceContext;
import com.liferay.portal.kernel.util.OrderByComparator;

import org.osgi.util.tracker.ServiceTracker;

import java.util.List;

/**
 * The persistence utility for the customized model service. This utility wraps {@link com.liferay.discussion.test.service.persistence.impl.CustomizedModelPersistenceImpl} and provides direct access to the database for CRUD operations. This utility should only be used by the service layer, as it must operate within a transaction. Never access this utility in a JSP, controller, model, or other front-end class.
 *
 * <p>
 * Caching information and settings can be found in <code>portal.properties</code>
 * </p>
 *
 * @author Brian Wing Shun Chan
 * @see CustomizedModelPersistence
 * @see com.liferay.discussion.test.service.persistence.impl.CustomizedModelPersistenceImpl
 * @generated
 */
@ProviderType
public class CustomizedModelUtil {
	/*
	 * NOTE FOR DEVELOPERS:
	 *
	 * Never modify this class directly. Modify <code>service.xml</code> and rerun ServiceBuilder to regenerate this class.
	 */

	/**
	 * @see com.liferay.portal.kernel.service.persistence.BasePersistence#clearCache()
	 */
	public static void clearCache() {
		getPersistence().clearCache();
	}

	/**
	 * @see com.liferay.portal.kernel.service.persistence.BasePersistence#clearCache(com.liferay.portal.kernel.model.BaseModel)
	 */
	public static void clearCache(CustomizedModel customizedModel) {
		getPersistence().clearCache(customizedModel);
	}

	/**
	 * @see com.liferay.portal.kernel.service.persistence.BasePersistence#countWithDynamicQuery(DynamicQuery)
	 */
	public static long countWithDynamicQuery(DynamicQuery dynamicQuery) {
		return getPersistence().countWithDynamicQuery(dynamicQuery);
	}

	/**
	 * @see com.liferay.portal.kernel.service.persistence.BasePersistence#findWithDynamicQuery(DynamicQuery)
	 */
	public static List<CustomizedModel> findWithDynamicQuery(
		DynamicQuery dynamicQuery) {
		return getPersistence().findWithDynamicQuery(dynamicQuery);
	}

	/**
	 * @see com.liferay.portal.kernel.service.persistence.BasePersistence#findWithDynamicQuery(DynamicQuery, int, int)
	 */
	public static List<CustomizedModel> findWithDynamicQuery(
		DynamicQuery dynamicQuery, int start, int end) {
		return getPersistence().findWithDynamicQuery(dynamicQuery, start, end);
	}

	/**
	 * @see com.liferay.portal.kernel.service.persistence.BasePersistence#findWithDynamicQuery(DynamicQuery, int, int, OrderByComparator)
	 */
	public static List<CustomizedModel> findWithDynamicQuery(
		DynamicQuery dynamicQuery, int start, int end,
		OrderByComparator<CustomizedModel> orderByComparator) {
		return getPersistence()
				   .findWithDynamicQuery(dynamicQuery, start, end,
			orderByComparator);
	}

	/**
	 * @see com.liferay.portal.kernel.service.persistence.BasePersistence#update(com.liferay.portal.kernel.model.BaseModel)
	 */
	public static CustomizedModel update(CustomizedModel customizedModel) {
		return getPersistence().update(customizedModel);
	}

	/**
	 * @see com.liferay.portal.kernel.service.persistence.BasePersistence#update(com.liferay.portal.kernel.model.BaseModel, ServiceContext)
	 */
	public static CustomizedModel update(CustomizedModel customizedModel,
		ServiceContext serviceContext) {
		return getPersistence().update(customizedModel, serviceContext);
	}

	/**
	* Returns all the customized models where uuid = &#63;.
	*
	* @param uuid the uuid
	* @return the matching customized models
	*/
	public static List<CustomizedModel> findByUuid(java.lang.String uuid) {
		return getPersistence().findByUuid(uuid);
	}

	/**
	* Returns a range of all the customized models where uuid = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link CustomizedModelModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param uuid the uuid
	* @param start the lower bound of the range of customized models
	* @param end the upper bound of the range of customized models (not inclusive)
	* @return the range of matching customized models
	*/
	public static List<CustomizedModel> findByUuid(java.lang.String uuid,
		int start, int end) {
		return getPersistence().findByUuid(uuid, start, end);
	}

	/**
	* Returns an ordered range of all the customized models where uuid = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link CustomizedModelModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param uuid the uuid
	* @param start the lower bound of the range of customized models
	* @param end the upper bound of the range of customized models (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the ordered range of matching customized models
	*/
	public static List<CustomizedModel> findByUuid(java.lang.String uuid,
		int start, int end, OrderByComparator<CustomizedModel> orderByComparator) {
		return getPersistence().findByUuid(uuid, start, end, orderByComparator);
	}

	/**
	* Returns an ordered range of all the customized models where uuid = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link CustomizedModelModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param uuid the uuid
	* @param start the lower bound of the range of customized models
	* @param end the upper bound of the range of customized models (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @param retrieveFromCache whether to retrieve from the finder cache
	* @return the ordered range of matching customized models
	*/
	public static List<CustomizedModel> findByUuid(java.lang.String uuid,
		int start, int end,
		OrderByComparator<CustomizedModel> orderByComparator,
		boolean retrieveFromCache) {
		return getPersistence()
				   .findByUuid(uuid, start, end, orderByComparator,
			retrieveFromCache);
	}

	/**
	* Returns the first customized model in the ordered set where uuid = &#63;.
	*
	* @param uuid the uuid
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching customized model
	* @throws NoSuchCustomizedModelException if a matching customized model could not be found
	*/
	public static CustomizedModel findByUuid_First(java.lang.String uuid,
		OrderByComparator<CustomizedModel> orderByComparator)
		throws com.liferay.discussion.test.exception.NoSuchCustomizedModelException {
		return getPersistence().findByUuid_First(uuid, orderByComparator);
	}

	/**
	* Returns the first customized model in the ordered set where uuid = &#63;.
	*
	* @param uuid the uuid
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching customized model, or <code>null</code> if a matching customized model could not be found
	*/
	public static CustomizedModel fetchByUuid_First(java.lang.String uuid,
		OrderByComparator<CustomizedModel> orderByComparator) {
		return getPersistence().fetchByUuid_First(uuid, orderByComparator);
	}

	/**
	* Returns the last customized model in the ordered set where uuid = &#63;.
	*
	* @param uuid the uuid
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching customized model
	* @throws NoSuchCustomizedModelException if a matching customized model could not be found
	*/
	public static CustomizedModel findByUuid_Last(java.lang.String uuid,
		OrderByComparator<CustomizedModel> orderByComparator)
		throws com.liferay.discussion.test.exception.NoSuchCustomizedModelException {
		return getPersistence().findByUuid_Last(uuid, orderByComparator);
	}

	/**
	* Returns the last customized model in the ordered set where uuid = &#63;.
	*
	* @param uuid the uuid
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching customized model, or <code>null</code> if a matching customized model could not be found
	*/
	public static CustomizedModel fetchByUuid_Last(java.lang.String uuid,
		OrderByComparator<CustomizedModel> orderByComparator) {
		return getPersistence().fetchByUuid_Last(uuid, orderByComparator);
	}

	/**
	* Returns the customized models before and after the current customized model in the ordered set where uuid = &#63;.
	*
	* @param modelId the primary key of the current customized model
	* @param uuid the uuid
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the previous, current, and next customized model
	* @throws NoSuchCustomizedModelException if a customized model with the primary key could not be found
	*/
	public static CustomizedModel[] findByUuid_PrevAndNext(long modelId,
		java.lang.String uuid,
		OrderByComparator<CustomizedModel> orderByComparator)
		throws com.liferay.discussion.test.exception.NoSuchCustomizedModelException {
		return getPersistence()
				   .findByUuid_PrevAndNext(modelId, uuid, orderByComparator);
	}

	/**
	* Removes all the customized models where uuid = &#63; from the database.
	*
	* @param uuid the uuid
	*/
	public static void removeByUuid(java.lang.String uuid) {
		getPersistence().removeByUuid(uuid);
	}

	/**
	* Returns the number of customized models where uuid = &#63;.
	*
	* @param uuid the uuid
	* @return the number of matching customized models
	*/
	public static int countByUuid(java.lang.String uuid) {
		return getPersistence().countByUuid(uuid);
	}

	/**
	* Returns the customized model where uuid = &#63; and groupId = &#63; or throws a {@link NoSuchCustomizedModelException} if it could not be found.
	*
	* @param uuid the uuid
	* @param groupId the group ID
	* @return the matching customized model
	* @throws NoSuchCustomizedModelException if a matching customized model could not be found
	*/
	public static CustomizedModel findByUUID_G(java.lang.String uuid,
		long groupId)
		throws com.liferay.discussion.test.exception.NoSuchCustomizedModelException {
		return getPersistence().findByUUID_G(uuid, groupId);
	}

	/**
	* Returns the customized model where uuid = &#63; and groupId = &#63; or returns <code>null</code> if it could not be found. Uses the finder cache.
	*
	* @param uuid the uuid
	* @param groupId the group ID
	* @return the matching customized model, or <code>null</code> if a matching customized model could not be found
	*/
	public static CustomizedModel fetchByUUID_G(java.lang.String uuid,
		long groupId) {
		return getPersistence().fetchByUUID_G(uuid, groupId);
	}

	/**
	* Returns the customized model where uuid = &#63; and groupId = &#63; or returns <code>null</code> if it could not be found, optionally using the finder cache.
	*
	* @param uuid the uuid
	* @param groupId the group ID
	* @param retrieveFromCache whether to retrieve from the finder cache
	* @return the matching customized model, or <code>null</code> if a matching customized model could not be found
	*/
	public static CustomizedModel fetchByUUID_G(java.lang.String uuid,
		long groupId, boolean retrieveFromCache) {
		return getPersistence().fetchByUUID_G(uuid, groupId, retrieveFromCache);
	}

	/**
	* Removes the customized model where uuid = &#63; and groupId = &#63; from the database.
	*
	* @param uuid the uuid
	* @param groupId the group ID
	* @return the customized model that was removed
	*/
	public static CustomizedModel removeByUUID_G(java.lang.String uuid,
		long groupId)
		throws com.liferay.discussion.test.exception.NoSuchCustomizedModelException {
		return getPersistence().removeByUUID_G(uuid, groupId);
	}

	/**
	* Returns the number of customized models where uuid = &#63; and groupId = &#63;.
	*
	* @param uuid the uuid
	* @param groupId the group ID
	* @return the number of matching customized models
	*/
	public static int countByUUID_G(java.lang.String uuid, long groupId) {
		return getPersistence().countByUUID_G(uuid, groupId);
	}

	/**
	* Returns all the customized models where uuid = &#63; and companyId = &#63;.
	*
	* @param uuid the uuid
	* @param companyId the company ID
	* @return the matching customized models
	*/
	public static List<CustomizedModel> findByUuid_C(java.lang.String uuid,
		long companyId) {
		return getPersistence().findByUuid_C(uuid, companyId);
	}

	/**
	* Returns a range of all the customized models where uuid = &#63; and companyId = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link CustomizedModelModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param uuid the uuid
	* @param companyId the company ID
	* @param start the lower bound of the range of customized models
	* @param end the upper bound of the range of customized models (not inclusive)
	* @return the range of matching customized models
	*/
	public static List<CustomizedModel> findByUuid_C(java.lang.String uuid,
		long companyId, int start, int end) {
		return getPersistence().findByUuid_C(uuid, companyId, start, end);
	}

	/**
	* Returns an ordered range of all the customized models where uuid = &#63; and companyId = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link CustomizedModelModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param uuid the uuid
	* @param companyId the company ID
	* @param start the lower bound of the range of customized models
	* @param end the upper bound of the range of customized models (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the ordered range of matching customized models
	*/
	public static List<CustomizedModel> findByUuid_C(java.lang.String uuid,
		long companyId, int start, int end,
		OrderByComparator<CustomizedModel> orderByComparator) {
		return getPersistence()
				   .findByUuid_C(uuid, companyId, start, end, orderByComparator);
	}

	/**
	* Returns an ordered range of all the customized models where uuid = &#63; and companyId = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link CustomizedModelModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param uuid the uuid
	* @param companyId the company ID
	* @param start the lower bound of the range of customized models
	* @param end the upper bound of the range of customized models (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @param retrieveFromCache whether to retrieve from the finder cache
	* @return the ordered range of matching customized models
	*/
	public static List<CustomizedModel> findByUuid_C(java.lang.String uuid,
		long companyId, int start, int end,
		OrderByComparator<CustomizedModel> orderByComparator,
		boolean retrieveFromCache) {
		return getPersistence()
				   .findByUuid_C(uuid, companyId, start, end,
			orderByComparator, retrieveFromCache);
	}

	/**
	* Returns the first customized model in the ordered set where uuid = &#63; and companyId = &#63;.
	*
	* @param uuid the uuid
	* @param companyId the company ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching customized model
	* @throws NoSuchCustomizedModelException if a matching customized model could not be found
	*/
	public static CustomizedModel findByUuid_C_First(java.lang.String uuid,
		long companyId, OrderByComparator<CustomizedModel> orderByComparator)
		throws com.liferay.discussion.test.exception.NoSuchCustomizedModelException {
		return getPersistence()
				   .findByUuid_C_First(uuid, companyId, orderByComparator);
	}

	/**
	* Returns the first customized model in the ordered set where uuid = &#63; and companyId = &#63;.
	*
	* @param uuid the uuid
	* @param companyId the company ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching customized model, or <code>null</code> if a matching customized model could not be found
	*/
	public static CustomizedModel fetchByUuid_C_First(java.lang.String uuid,
		long companyId, OrderByComparator<CustomizedModel> orderByComparator) {
		return getPersistence()
				   .fetchByUuid_C_First(uuid, companyId, orderByComparator);
	}

	/**
	* Returns the last customized model in the ordered set where uuid = &#63; and companyId = &#63;.
	*
	* @param uuid the uuid
	* @param companyId the company ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching customized model
	* @throws NoSuchCustomizedModelException if a matching customized model could not be found
	*/
	public static CustomizedModel findByUuid_C_Last(java.lang.String uuid,
		long companyId, OrderByComparator<CustomizedModel> orderByComparator)
		throws com.liferay.discussion.test.exception.NoSuchCustomizedModelException {
		return getPersistence()
				   .findByUuid_C_Last(uuid, companyId, orderByComparator);
	}

	/**
	* Returns the last customized model in the ordered set where uuid = &#63; and companyId = &#63;.
	*
	* @param uuid the uuid
	* @param companyId the company ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching customized model, or <code>null</code> if a matching customized model could not be found
	*/
	public static CustomizedModel fetchByUuid_C_Last(java.lang.String uuid,
		long companyId, OrderByComparator<CustomizedModel> orderByComparator) {
		return getPersistence()
				   .fetchByUuid_C_Last(uuid, companyId, orderByComparator);
	}

	/**
	* Returns the customized models before and after the current customized model in the ordered set where uuid = &#63; and companyId = &#63;.
	*
	* @param modelId the primary key of the current customized model
	* @param uuid the uuid
	* @param companyId the company ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the previous, current, and next customized model
	* @throws NoSuchCustomizedModelException if a customized model with the primary key could not be found
	*/
	public static CustomizedModel[] findByUuid_C_PrevAndNext(long modelId,
		java.lang.String uuid, long companyId,
		OrderByComparator<CustomizedModel> orderByComparator)
		throws com.liferay.discussion.test.exception.NoSuchCustomizedModelException {
		return getPersistence()
				   .findByUuid_C_PrevAndNext(modelId, uuid, companyId,
			orderByComparator);
	}

	/**
	* Removes all the customized models where uuid = &#63; and companyId = &#63; from the database.
	*
	* @param uuid the uuid
	* @param companyId the company ID
	*/
	public static void removeByUuid_C(java.lang.String uuid, long companyId) {
		getPersistence().removeByUuid_C(uuid, companyId);
	}

	/**
	* Returns the number of customized models where uuid = &#63; and companyId = &#63;.
	*
	* @param uuid the uuid
	* @param companyId the company ID
	* @return the number of matching customized models
	*/
	public static int countByUuid_C(java.lang.String uuid, long companyId) {
		return getPersistence().countByUuid_C(uuid, companyId);
	}

	/**
	* Returns all the customized models where status = &#63;.
	*
	* @param status the status
	* @return the matching customized models
	*/
	public static List<CustomizedModel> findByStatus(int status) {
		return getPersistence().findByStatus(status);
	}

	/**
	* Returns a range of all the customized models where status = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link CustomizedModelModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param status the status
	* @param start the lower bound of the range of customized models
	* @param end the upper bound of the range of customized models (not inclusive)
	* @return the range of matching customized models
	*/
	public static List<CustomizedModel> findByStatus(int status, int start,
		int end) {
		return getPersistence().findByStatus(status, start, end);
	}

	/**
	* Returns an ordered range of all the customized models where status = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link CustomizedModelModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param status the status
	* @param start the lower bound of the range of customized models
	* @param end the upper bound of the range of customized models (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the ordered range of matching customized models
	*/
	public static List<CustomizedModel> findByStatus(int status, int start,
		int end, OrderByComparator<CustomizedModel> orderByComparator) {
		return getPersistence()
				   .findByStatus(status, start, end, orderByComparator);
	}

	/**
	* Returns an ordered range of all the customized models where status = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link CustomizedModelModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param status the status
	* @param start the lower bound of the range of customized models
	* @param end the upper bound of the range of customized models (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @param retrieveFromCache whether to retrieve from the finder cache
	* @return the ordered range of matching customized models
	*/
	public static List<CustomizedModel> findByStatus(int status, int start,
		int end, OrderByComparator<CustomizedModel> orderByComparator,
		boolean retrieveFromCache) {
		return getPersistence()
				   .findByStatus(status, start, end, orderByComparator,
			retrieveFromCache);
	}

	/**
	* Returns the first customized model in the ordered set where status = &#63;.
	*
	* @param status the status
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching customized model
	* @throws NoSuchCustomizedModelException if a matching customized model could not be found
	*/
	public static CustomizedModel findByStatus_First(int status,
		OrderByComparator<CustomizedModel> orderByComparator)
		throws com.liferay.discussion.test.exception.NoSuchCustomizedModelException {
		return getPersistence().findByStatus_First(status, orderByComparator);
	}

	/**
	* Returns the first customized model in the ordered set where status = &#63;.
	*
	* @param status the status
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching customized model, or <code>null</code> if a matching customized model could not be found
	*/
	public static CustomizedModel fetchByStatus_First(int status,
		OrderByComparator<CustomizedModel> orderByComparator) {
		return getPersistence().fetchByStatus_First(status, orderByComparator);
	}

	/**
	* Returns the last customized model in the ordered set where status = &#63;.
	*
	* @param status the status
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching customized model
	* @throws NoSuchCustomizedModelException if a matching customized model could not be found
	*/
	public static CustomizedModel findByStatus_Last(int status,
		OrderByComparator<CustomizedModel> orderByComparator)
		throws com.liferay.discussion.test.exception.NoSuchCustomizedModelException {
		return getPersistence().findByStatus_Last(status, orderByComparator);
	}

	/**
	* Returns the last customized model in the ordered set where status = &#63;.
	*
	* @param status the status
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching customized model, or <code>null</code> if a matching customized model could not be found
	*/
	public static CustomizedModel fetchByStatus_Last(int status,
		OrderByComparator<CustomizedModel> orderByComparator) {
		return getPersistence().fetchByStatus_Last(status, orderByComparator);
	}

	/**
	* Returns the customized models before and after the current customized model in the ordered set where status = &#63;.
	*
	* @param modelId the primary key of the current customized model
	* @param status the status
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the previous, current, and next customized model
	* @throws NoSuchCustomizedModelException if a customized model with the primary key could not be found
	*/
	public static CustomizedModel[] findByStatus_PrevAndNext(long modelId,
		int status, OrderByComparator<CustomizedModel> orderByComparator)
		throws com.liferay.discussion.test.exception.NoSuchCustomizedModelException {
		return getPersistence()
				   .findByStatus_PrevAndNext(modelId, status, orderByComparator);
	}

	/**
	* Removes all the customized models where status = &#63; from the database.
	*
	* @param status the status
	*/
	public static void removeByStatus(int status) {
		getPersistence().removeByStatus(status);
	}

	/**
	* Returns the number of customized models where status = &#63;.
	*
	* @param status the status
	* @return the number of matching customized models
	*/
	public static int countByStatus(int status) {
		return getPersistence().countByStatus(status);
	}

	/**
	* Returns all the customized models where groupId = &#63; and status = &#63;.
	*
	* @param groupId the group ID
	* @param status the status
	* @return the matching customized models
	*/
	public static List<CustomizedModel> findByGroupAndStatus(long groupId,
		int status) {
		return getPersistence().findByGroupAndStatus(groupId, status);
	}

	/**
	* Returns a range of all the customized models where groupId = &#63; and status = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link CustomizedModelModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param groupId the group ID
	* @param status the status
	* @param start the lower bound of the range of customized models
	* @param end the upper bound of the range of customized models (not inclusive)
	* @return the range of matching customized models
	*/
	public static List<CustomizedModel> findByGroupAndStatus(long groupId,
		int status, int start, int end) {
		return getPersistence().findByGroupAndStatus(groupId, status, start, end);
	}

	/**
	* Returns an ordered range of all the customized models where groupId = &#63; and status = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link CustomizedModelModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param groupId the group ID
	* @param status the status
	* @param start the lower bound of the range of customized models
	* @param end the upper bound of the range of customized models (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the ordered range of matching customized models
	*/
	public static List<CustomizedModel> findByGroupAndStatus(long groupId,
		int status, int start, int end,
		OrderByComparator<CustomizedModel> orderByComparator) {
		return getPersistence()
				   .findByGroupAndStatus(groupId, status, start, end,
			orderByComparator);
	}

	/**
	* Returns an ordered range of all the customized models where groupId = &#63; and status = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link CustomizedModelModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param groupId the group ID
	* @param status the status
	* @param start the lower bound of the range of customized models
	* @param end the upper bound of the range of customized models (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @param retrieveFromCache whether to retrieve from the finder cache
	* @return the ordered range of matching customized models
	*/
	public static List<CustomizedModel> findByGroupAndStatus(long groupId,
		int status, int start, int end,
		OrderByComparator<CustomizedModel> orderByComparator,
		boolean retrieveFromCache) {
		return getPersistence()
				   .findByGroupAndStatus(groupId, status, start, end,
			orderByComparator, retrieveFromCache);
	}

	/**
	* Returns the first customized model in the ordered set where groupId = &#63; and status = &#63;.
	*
	* @param groupId the group ID
	* @param status the status
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching customized model
	* @throws NoSuchCustomizedModelException if a matching customized model could not be found
	*/
	public static CustomizedModel findByGroupAndStatus_First(long groupId,
		int status, OrderByComparator<CustomizedModel> orderByComparator)
		throws com.liferay.discussion.test.exception.NoSuchCustomizedModelException {
		return getPersistence()
				   .findByGroupAndStatus_First(groupId, status,
			orderByComparator);
	}

	/**
	* Returns the first customized model in the ordered set where groupId = &#63; and status = &#63;.
	*
	* @param groupId the group ID
	* @param status the status
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching customized model, or <code>null</code> if a matching customized model could not be found
	*/
	public static CustomizedModel fetchByGroupAndStatus_First(long groupId,
		int status, OrderByComparator<CustomizedModel> orderByComparator) {
		return getPersistence()
				   .fetchByGroupAndStatus_First(groupId, status,
			orderByComparator);
	}

	/**
	* Returns the last customized model in the ordered set where groupId = &#63; and status = &#63;.
	*
	* @param groupId the group ID
	* @param status the status
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching customized model
	* @throws NoSuchCustomizedModelException if a matching customized model could not be found
	*/
	public static CustomizedModel findByGroupAndStatus_Last(long groupId,
		int status, OrderByComparator<CustomizedModel> orderByComparator)
		throws com.liferay.discussion.test.exception.NoSuchCustomizedModelException {
		return getPersistence()
				   .findByGroupAndStatus_Last(groupId, status, orderByComparator);
	}

	/**
	* Returns the last customized model in the ordered set where groupId = &#63; and status = &#63;.
	*
	* @param groupId the group ID
	* @param status the status
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching customized model, or <code>null</code> if a matching customized model could not be found
	*/
	public static CustomizedModel fetchByGroupAndStatus_Last(long groupId,
		int status, OrderByComparator<CustomizedModel> orderByComparator) {
		return getPersistence()
				   .fetchByGroupAndStatus_Last(groupId, status,
			orderByComparator);
	}

	/**
	* Returns the customized models before and after the current customized model in the ordered set where groupId = &#63; and status = &#63;.
	*
	* @param modelId the primary key of the current customized model
	* @param groupId the group ID
	* @param status the status
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the previous, current, and next customized model
	* @throws NoSuchCustomizedModelException if a customized model with the primary key could not be found
	*/
	public static CustomizedModel[] findByGroupAndStatus_PrevAndNext(
		long modelId, long groupId, int status,
		OrderByComparator<CustomizedModel> orderByComparator)
		throws com.liferay.discussion.test.exception.NoSuchCustomizedModelException {
		return getPersistence()
				   .findByGroupAndStatus_PrevAndNext(modelId, groupId, status,
			orderByComparator);
	}

	/**
	* Returns all the customized models that the user has permission to view where groupId = &#63; and status = &#63;.
	*
	* @param groupId the group ID
	* @param status the status
	* @return the matching customized models that the user has permission to view
	*/
	public static List<CustomizedModel> filterFindByGroupAndStatus(
		long groupId, int status) {
		return getPersistence().filterFindByGroupAndStatus(groupId, status);
	}

	/**
	* Returns a range of all the customized models that the user has permission to view where groupId = &#63; and status = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link CustomizedModelModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param groupId the group ID
	* @param status the status
	* @param start the lower bound of the range of customized models
	* @param end the upper bound of the range of customized models (not inclusive)
	* @return the range of matching customized models that the user has permission to view
	*/
	public static List<CustomizedModel> filterFindByGroupAndStatus(
		long groupId, int status, int start, int end) {
		return getPersistence()
				   .filterFindByGroupAndStatus(groupId, status, start, end);
	}

	/**
	* Returns an ordered range of all the customized models that the user has permissions to view where groupId = &#63; and status = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link CustomizedModelModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param groupId the group ID
	* @param status the status
	* @param start the lower bound of the range of customized models
	* @param end the upper bound of the range of customized models (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the ordered range of matching customized models that the user has permission to view
	*/
	public static List<CustomizedModel> filterFindByGroupAndStatus(
		long groupId, int status, int start, int end,
		OrderByComparator<CustomizedModel> orderByComparator) {
		return getPersistence()
				   .filterFindByGroupAndStatus(groupId, status, start, end,
			orderByComparator);
	}

	/**
	* Returns the customized models before and after the current customized model in the ordered set of customized models that the user has permission to view where groupId = &#63; and status = &#63;.
	*
	* @param modelId the primary key of the current customized model
	* @param groupId the group ID
	* @param status the status
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the previous, current, and next customized model
	* @throws NoSuchCustomizedModelException if a customized model with the primary key could not be found
	*/
	public static CustomizedModel[] filterFindByGroupAndStatus_PrevAndNext(
		long modelId, long groupId, int status,
		OrderByComparator<CustomizedModel> orderByComparator)
		throws com.liferay.discussion.test.exception.NoSuchCustomizedModelException {
		return getPersistence()
				   .filterFindByGroupAndStatus_PrevAndNext(modelId, groupId,
			status, orderByComparator);
	}

	/**
	* Removes all the customized models where groupId = &#63; and status = &#63; from the database.
	*
	* @param groupId the group ID
	* @param status the status
	*/
	public static void removeByGroupAndStatus(long groupId, int status) {
		getPersistence().removeByGroupAndStatus(groupId, status);
	}

	/**
	* Returns the number of customized models where groupId = &#63; and status = &#63;.
	*
	* @param groupId the group ID
	* @param status the status
	* @return the number of matching customized models
	*/
	public static int countByGroupAndStatus(long groupId, int status) {
		return getPersistence().countByGroupAndStatus(groupId, status);
	}

	/**
	* Returns the number of customized models that the user has permission to view where groupId = &#63; and status = &#63;.
	*
	* @param groupId the group ID
	* @param status the status
	* @return the number of matching customized models that the user has permission to view
	*/
	public static int filterCountByGroupAndStatus(long groupId, int status) {
		return getPersistence().filterCountByGroupAndStatus(groupId, status);
	}

	/**
	* Caches the customized model in the entity cache if it is enabled.
	*
	* @param customizedModel the customized model
	*/
	public static void cacheResult(CustomizedModel customizedModel) {
		getPersistence().cacheResult(customizedModel);
	}

	/**
	* Caches the customized models in the entity cache if it is enabled.
	*
	* @param customizedModels the customized models
	*/
	public static void cacheResult(List<CustomizedModel> customizedModels) {
		getPersistence().cacheResult(customizedModels);
	}

	/**
	* Creates a new customized model with the primary key. Does not add the customized model to the database.
	*
	* @param modelId the primary key for the new customized model
	* @return the new customized model
	*/
	public static CustomizedModel create(long modelId) {
		return getPersistence().create(modelId);
	}

	/**
	* Removes the customized model with the primary key from the database. Also notifies the appropriate model listeners.
	*
	* @param modelId the primary key of the customized model
	* @return the customized model that was removed
	* @throws NoSuchCustomizedModelException if a customized model with the primary key could not be found
	*/
	public static CustomizedModel remove(long modelId)
		throws com.liferay.discussion.test.exception.NoSuchCustomizedModelException {
		return getPersistence().remove(modelId);
	}

	public static CustomizedModel updateImpl(CustomizedModel customizedModel) {
		return getPersistence().updateImpl(customizedModel);
	}

	/**
	* Returns the customized model with the primary key or throws a {@link NoSuchCustomizedModelException} if it could not be found.
	*
	* @param modelId the primary key of the customized model
	* @return the customized model
	* @throws NoSuchCustomizedModelException if a customized model with the primary key could not be found
	*/
	public static CustomizedModel findByPrimaryKey(long modelId)
		throws com.liferay.discussion.test.exception.NoSuchCustomizedModelException {
		return getPersistence().findByPrimaryKey(modelId);
	}

	/**
	* Returns the customized model with the primary key or returns <code>null</code> if it could not be found.
	*
	* @param modelId the primary key of the customized model
	* @return the customized model, or <code>null</code> if a customized model with the primary key could not be found
	*/
	public static CustomizedModel fetchByPrimaryKey(long modelId) {
		return getPersistence().fetchByPrimaryKey(modelId);
	}

	public static java.util.Map<java.io.Serializable, CustomizedModel> fetchByPrimaryKeys(
		java.util.Set<java.io.Serializable> primaryKeys) {
		return getPersistence().fetchByPrimaryKeys(primaryKeys);
	}

	/**
	* Returns all the customized models.
	*
	* @return the customized models
	*/
	public static List<CustomizedModel> findAll() {
		return getPersistence().findAll();
	}

	/**
	* Returns a range of all the customized models.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link CustomizedModelModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param start the lower bound of the range of customized models
	* @param end the upper bound of the range of customized models (not inclusive)
	* @return the range of customized models
	*/
	public static List<CustomizedModel> findAll(int start, int end) {
		return getPersistence().findAll(start, end);
	}

	/**
	* Returns an ordered range of all the customized models.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link CustomizedModelModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param start the lower bound of the range of customized models
	* @param end the upper bound of the range of customized models (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the ordered range of customized models
	*/
	public static List<CustomizedModel> findAll(int start, int end,
		OrderByComparator<CustomizedModel> orderByComparator) {
		return getPersistence().findAll(start, end, orderByComparator);
	}

	/**
	* Returns an ordered range of all the customized models.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link CustomizedModelModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param start the lower bound of the range of customized models
	* @param end the upper bound of the range of customized models (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @param retrieveFromCache whether to retrieve from the finder cache
	* @return the ordered range of customized models
	*/
	public static List<CustomizedModel> findAll(int start, int end,
		OrderByComparator<CustomizedModel> orderByComparator,
		boolean retrieveFromCache) {
		return getPersistence()
				   .findAll(start, end, orderByComparator, retrieveFromCache);
	}

	/**
	* Removes all the customized models from the database.
	*/
	public static void removeAll() {
		getPersistence().removeAll();
	}

	/**
	* Returns the number of customized models.
	*
	* @return the number of customized models
	*/
	public static int countAll() {
		return getPersistence().countAll();
	}

	public static java.util.Set<java.lang.String> getBadColumnNames() {
		return getPersistence().getBadColumnNames();
	}

	public static CustomizedModelPersistence getPersistence() {
		return _serviceTracker.getService();
	}

	private static ServiceTracker<CustomizedModelPersistence, CustomizedModelPersistence> _serviceTracker =
		ServiceTrackerFactory.open(CustomizedModelPersistence.class);
}