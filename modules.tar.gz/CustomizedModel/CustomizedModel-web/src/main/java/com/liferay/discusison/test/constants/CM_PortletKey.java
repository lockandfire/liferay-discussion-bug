package com.liferay.discusison.test.constants;

public class CM_PortletKey {

	public static final String CM_PORTLET = "com_liferay_discussion_test_portlet";
}
