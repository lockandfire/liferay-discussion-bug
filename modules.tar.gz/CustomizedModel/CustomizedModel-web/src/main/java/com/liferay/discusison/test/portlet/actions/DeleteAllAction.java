package com.liferay.discusison.test.portlet.actions;

import com.liferay.discusison.test.constants.CM_PortletKey;
import com.liferay.discussion.test.service.CustomizedModelLocalService;
import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.liferay.portal.kernel.portlet.bridges.mvc.BaseMVCActionCommand;
import com.liferay.portal.kernel.portlet.bridges.mvc.MVCActionCommand;
import com.liferay.portal.kernel.util.ParamUtil;

import javax.portlet.ActionRequest;
import javax.portlet.ActionResponse;

import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;

@Component(
	immediate = true,
	property = {
		"javax.portlet.name=" + CM_PortletKey.CM_PORTLET,
		"mvc.command.name=deleteAll"
	},
	service = MVCActionCommand.class
)

public class DeleteAllAction extends BaseMVCActionCommand {

	@Override
	protected void doProcessAction(ActionRequest actionRequest, ActionResponse actionResponse) throws Exception {
		long groupId = ParamUtil.getLong(actionRequest, "groupId");
		_customizedModelLocalService.deleteAll(groupId);
	}

	@Reference(unbind ="-")
	protected void setCustomizedModelLocalService(CustomizedModelLocalService customizedModelLocalService) {
		_customizedModelLocalService = customizedModelLocalService;
	}
	protected CustomizedModelLocalService _customizedModelLocalService;
	
}